import { useEffect, useState } from "react";
import { useLocation } from "react-router";
import "./manga.css";

/** The Web Manga Skin intentionally excludes Workbench, HUD, Office and desktop. */
export const EXCLUDED_MANGA_PATHS = [
  "/qubit-workbench", "/qubit-hud", "/qubit-office", "/qubit-office2", "/qubit-office3",
] as const;
export const MANGA_SKIN_KEY = "qubit-manga-skin-enabled";

function eligible(path: string): boolean {
  return !EXCLUDED_MANGA_PATHS.some((excluded) => path === excluded || path.startsWith(excluded + "/"));
}
function storedEnabled(): boolean {
  try { return window.localStorage.getItem(MANGA_SKIN_KEY) === "true"; }
  catch { return false; }
}

/** Mount exactly once INSIDE the React Router. No page or theme files are modified. */
export function MangaSkinGate() {
  const { pathname } = useLocation();
  const [enabled, setEnabled] = useState(storedEnabled);
  useEffect(() => {
    const active = enabled && eligible(pathname);
    if (active) document.documentElement.setAttribute("data-qubit-manga", "on");
    else document.documentElement.removeAttribute("data-qubit-manga");
    return () => document.documentElement.removeAttribute("data-qubit-manga");
  }, [enabled, pathname]);
  useEffect(() => {
    const sync = () => setEnabled(storedEnabled());
    window.addEventListener("storage", sync);
    window.addEventListener("qubit-manga-change", sync);
    return () => { window.removeEventListener("storage", sync); window.removeEventListener("qubit-manga-change", sync); };
  }, []);
  return null;
}

/** Add this small toggle in your sidebar footer or theme picker. */
export function MangaSkinToggle() {
  const [enabled, setEnabled] = useState(storedEnabled);
  useEffect(() => {
    const sync = () => setEnabled(storedEnabled());
    window.addEventListener("storage", sync);
    window.addEventListener("qubit-manga-change", sync);
    return () => { window.removeEventListener("storage", sync); window.removeEventListener("qubit-manga-change", sync); };
  }, []);
  return <button type="button" aria-pressed={enabled} title="Toggle Manga Skin"
    style={{border:"2px solid #ff269a",background:enabled?"#ffe500":"#171027",color:enabled?"#080615":"#fff0ff",padding:"6px 10px",fontSize:12,fontWeight:800,borderRadius:4}}
    onClick={() => {
      const next = !enabled;
      try { window.localStorage.setItem(MANGA_SKIN_KEY, String(next)); } catch { /* private mode */ }
      setEnabled(next);
      window.dispatchEvent(new Event("qubit-manga-change"));
    }}>Manga {enabled ? "ON" : "OFF"}</button>;
}
