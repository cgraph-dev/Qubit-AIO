# Install Qubit Web Manga Skin (opt-in)

**Target:** `frontend/qubit-web` of cgraph-dev/Qubit-AIO. Nothing here writes to GitHub.

## Files

1. Copy `src/manga-skin/` into `frontend/qubit-web/src/manga-skin/`.
2. Copy `public/manga-ui/` into `frontend/qubit-web/public/manga-ui/`.
3. Edit `frontend/qubit-web/src/App.tsx`:
   - Add `import { MangaSkinGate, MangaSkinToggle } from "@/manga-skin";`
   - Within the `ProfileProvider` contents, add `<MangaSkinGate />` (before the main outer `<div>`).
   - Add `<MangaSkinToggle />` to the sidebar footer control area or beside the existing ThemeSwitcher. The toggle is opt-in and persists in localStorage.
4. From `frontend/qubit-web`, run `npm run typecheck`, `npm run test`, and `npm run build`.
5. Navigate through web-dashboard routes and compare against screenshots before shipping.

**Exclusions:** `/qubit-workbench`, `/qubit-hud`, `/qubit-office`, `/qubit-office2`, `/qubit-office3` and descendant paths. The desktop app is not edited. The gate automatically clears the skin attribute on excluded routes.

**Implementation notes:**
- `manga.css` is scoped behind `html[data-qubit-manga="on"]`; existing Q2 appearance remains default.
- Uses Qubit `.qplate`, `.qagent-sidebar`, `.qchat`, `.settings-*`, plus Sakuga `::part` seams.
- Assets are standalone text-free, alpha-transparent SVG/PNG visuals for optional usage in further CSS customizations.
- Avoid using full-panel raster imagery as a background for text-heavy responsive content; prefer CSS borders / corner ornaments for accessibility.
- Web dashboard is **not fully pixel-verified**, and no files have been built/tested inside the repository. Review all affected route states before merging.
- The CSS does not target server-served Workbench internals or any desktop source.
