# Web-dashboard manga scope

## Implemented base skin
- Left nav rail, section headers, row hover/selected, gateway region shared plate tokens
- Chat right-hand plate, section headers, rows and model area shared tokens
- Cards, settings sections/rows, form fields, dialogs and focus styles
- Sakuga button/input visual parts without replacing Sakuga animation logic
- Route exclusions enforced by `MangaSkinGate` during React navigation

## SVG/PNG asset categories
- Application shell: sidebar expanded/collapsed, header/footer/page bars, right rail
- Page surfaces: chat, terminal, analytics, table, tasks, files, settings, calendar, voice
- Interaction: 6 buttons, 5 nav states, 7 fields, 6 badges, 4 corner shapes, impacts and separators

## Still to verify manually
- Main and mobile layouts of each React route, validation/errors/loading/empty states
- Tailwind/ds cascade across all page-level CSS modules and third-party components
- User-selected non-Q2 themes, keyboard/focus interaction and zoom levels
- Runtime theme switching and Sakuga shadow-tree specifics

## Explicit exclusions
- `/qubit-workbench`, `/qubit-hud`, `/qubit-office`, `/qubit-office2`, `/qubit-office3`, all their child routes; desktop app.
