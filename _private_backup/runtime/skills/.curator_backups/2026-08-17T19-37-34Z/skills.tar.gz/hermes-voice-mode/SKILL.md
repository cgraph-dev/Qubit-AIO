---
name: hermes-voice-mode
description: Setup, configure, and troubleshoot Hermes voice mode (STT + TTS), push-to-talk, microphone issues, and audio provider quirks.
title: Hermes Voice Mode Setup & Troubleshooting
trigger:
  - user asks about voice mode, voice-to-voice, /voice, or push-to-talk
  - Ctrl+B or voice record key not working
  - TTS not playing, STT not transcribing, or microphone issues in Hermes
  - setting up speech-to-text or text-to-speech
  - configuring audio or voice providers like openai, edge, elevenlabs
  - faster-whisper, sounddevice, pyaudio, or PortAudio errors
---

# Hermes Voice Mode Setup & Troubleshooting

## 1. System Dependencies

Voice mode requires PortAudio at the system level and Python audio libraries in the **Hermes venv**.

### Install system libraries
```bash
sudo apt-get install -y libportaudio2 libportaudiocpp0 portaudio19-dev
```

> **Pitfall:** If `dpkg` was interrupted (e.g., by a previous upgrade), apt will fail with:
> `E: dpkg was interrupted, you must manually run 'sudo dpkg --configure -a'`
> Fix this **first** before installing anything else.

### Install Python libraries (in Hermes venv)
```bash
~/.hermes/hermes-agent/venv/bin/pip install sounddevice pyaudio SpeechRecognition
```

> **Pitfall:** Always use the **Hermes venv Python** (`~/.hermes/hermes-agent/venv/bin/python3`), not system Python. Voice imports will fail from system Python even if the packages appear installed.

### Verify audio environment
```bash
~/.hermes/hermes-agent/venv/bin/python3 -c "
from tools.voice_mode import detect_audio_environment
import json
print(json.dumps(detect_audio_environment(), indent=2))
"
```
Expected: `{"available": true, "warnings": [], "notices": []}`

## 2. Configuration

### Enable voice mode
```bash
hermes config set stt.enabled true
hermes config set stt.provider local          # faster-whisper, free, offline
hermes config set tts.provider openai         # or edge, elevenlabs, etc.
hermes config set voice.record_key ctrl+b     # or ctrl+space, alt+space, etc.
hermes config set voice.beep_enabled true
```

### OpenAI TTS provider quirks
When using **OpenAI TTS through the Nous gateway**, the only supported model is:
```yaml
tts:
  provider: openai
  openai:
    model: gpt-4o-mini-tts      # NOT tts-1
    voice: nova                  # alloy, echo, fable, onyx, nova, shimmer
```

> **Pitfall:** Setting `model: tts-1` produces:
> `Unsupported managed OpenAI speech model. Supported models: ['gpt-4o-mini-tts']`
> Always use `gpt-4o-mini-tts` for gateway-routed OpenAI TTS.

### Pro audio interface threshold fix
Professional audio interfaces (Focusrite Scarlett, etc.) output lower software signal levels than built-in mics. The default `silence_threshold: 200` causes all recordings to be discarded as "too quiet."

**Symptom:** Recording starts/stops but returns `None` (no WAV file), or `peak_rms` is < 200.

**Fix:** Lower the threshold dramatically:
```bash
hermes config set voice.silence_threshold 20    # or even 10 for very quiet setups
```

Also ensure hardware gain is adequate:
- Turn the interface gain knob to ~12 o'clock
- Speak 6-12 inches from the mic
- Watch for green halo LED flashes (not solid red = clipping)

## 3. Usage

### Interactive voice-to-voice
```bash
hermes                    # start interactive session
/voice on                 # enable voice-to-voice mode
# Press Ctrl+B -> speak -> press Ctrl+B again (or stay silent 3s)
/voice off                # disable
```

### Voice mode commands
| Command | Effect |
|---------|--------|
| `/voice on` | Voice-to-voice (speak in, spoken reply) |
| `/voice tts` | Text-to-speech only (you type, AI speaks) |
| `/voice off` | Disable voice output |

## 4. Troubleshooting Checklist

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| Ctrl+B does nothing | Not in interactive session, or voice mode not on | Run `hermes` (not `hermes chat -q`), then `/voice on` |
| Recording beeps but no file | Threshold too high for pro audio interface | `hermes config set voice.silence_threshold 20` |
| `ImportError: No module named sounddevice` | Not installed in Hermes venv | `venv/bin/pip install sounddevice pyaudio SpeechRecognition` |
| `PortAudioError: Invalid sample rate` | Hardware doesn't support 16kHz directly | Use PipeWire/Pulse default device (index 8/9/10), not raw ALSA hw |
| `paInvalidSampleRate` on Scarlett | Direct ALSA hw device rejects 16kHz | The `default` device (index 10) handles resampling; use that |
| TTS fails with "Unsupported managed OpenAI speech model" | Wrong model name for gateway | Set `tts.openai.model` to `gpt-4o-mini-tts` |
| `faster-whisper CUDA runtime failed` | Missing CUDA libs | Falls back to CPU automatically; harmless warning |
| No audio over SSH | No PulseAudio/PipeWire forwarding | Export `PULSE_SERVER` or `XDG_RUNTIME_DIR` |

## 5. Quick Diagnostic Script

Run this to test the full voice pipeline:

```bash
~/.hermes/hermes-agent/venv/bin/python3 -c "
from tools.voice_mode import AudioRecorder, transcribe_recording
import time

rec = AudioRecorder()
print('SPEAK NOW for 3 seconds...')
rec.start()
time.sleep(3)
print('Has spoken:', rec._has_spoken)
print('Peak RMS:', rec._peak_rms)
path = rec.stop()
rec.shutdown()
print('File:', path)

if path:
    result = transcribe_recording(path)
    print('Transcript:', result.get('transcript'))
"
```

Expected: `peak_rms` > threshold, `path` is a WAV file, transcript contains your speech.

## References

- `references/provider-quirks.md` - Provider-specific compatibility notes (OpenAI, Edge, ElevenLabs, etc.)
- `references/hardware-notes.md` - Known audio interface quirks and gain settings
